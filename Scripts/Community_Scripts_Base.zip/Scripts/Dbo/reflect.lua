-- DBO Reflect Script (Exemplo)
macro(1000, "DBO Reflect", function()
  say("reflect")
end)
